package one;

public class Simulator {
	
	public static void main(String[] args) {
		
		Car myCar = new Car();
		myCar.run();	
	}

}
