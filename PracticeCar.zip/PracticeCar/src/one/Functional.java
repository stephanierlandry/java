package one;

public interface Functional {
	
	public void function();

	void function(int psi);

	void function(String batteryType);

	void function(int oilAmt, String oilType);

}
