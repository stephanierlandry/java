package one;

public interface Functional {
	
	public void function();

}
